import os
# import sys
import random
import optuna
import pickle
import pandas as pd

# import matplotlib.pyplot as plt
import numpy as np
import torch 
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from sklearn import metrics

from rdkit import Chem
from rdkit.Chem import AllChem, DataStructs





def get_data(): 
    with open('./DATA/exp_6_split/train_classification.pkl', 'rb') as f:
        A = pickle.load(f)        

    with open('./DATA/exp_6_split/val_classification.pkl', 'rb') as f:
        B = pickle.load(f)        
        
    with open('./DATA/exp_6_split/test_classification.pkl', 'rb') as f:
        C = pickle.load(f)        
    
           # Train, Val & Test
    return A, B, C
    


class EarlyStopping:
    """Early stops the training if validation loss doesn't improve after a given patience."""
    def __init__(self, patience=7, verbose=False, delta=0, path='checkpoint.pt'):
        """
        Args:
            patience (int): How long to wait after last time validation loss improved.
                            Default: 7
            verbose (bool): If True, prints a message for each validation loss improvement. 
                            Default: False
            delta (float): Minimum change in the monitored quantity to qualify as an improvement.
                            Default: 0
            path (str): Path for the checkpoint to be saved to.
                            Default: 'checkpoint.pt'
        """
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta
        self.path = path

    def __call__(self, trial, epoch, val_loss, model):

        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(trial, val_loss, model, epoch)
            # trial.report(val_loss, epoch) #### TESTING
        elif score > self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(trial, val_loss, model, epoch)
            self.counter = 0
        
        return self.val_loss_min

    def save_checkpoint(self, trial, val_loss, model, epoch):
        '''Saves model when validation loss decrease.'''
        if os.path.isdir('./saved_models_st/{}'.format(trial.number)) == False: 
            os.system('mkdir ./saved_models_st/{}'.format(trial.number)) # create directory that saves the model 
        self.path = './saved_models_st/{}/model_checkpoint.pt'.format(trial.number)
        torch.save(model, self.path)
        self.val_loss_min = val_loss


class Reg(nn.Module):
    def __init__(self, layer_1_dim, layer_2_dim, dropout_rate):
        super(Reg, self).__init__()
        self.fc1 = nn.Linear(1024       , layer_1_dim)
        self.fc2 = nn.Linear(layer_1_dim, layer_2_dim)
        self.fc3 = nn.Linear(layer_2_dim, 1)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(p=dropout_rate)
        self.batchnorm1 = nn.BatchNorm1d(layer_1_dim)
        self.batchnorm2 = nn.BatchNorm1d(layer_2_dim)

    def forward(self, x):
        x = F.relu(self.dropout(self.fc1(x)))
        x = self.batchnorm1(x)
        x = F.relu(self.dropout(self.fc2(x)))
        x = self.batchnorm2(x)
        x = self.fc3(x)

        return x
    


def binary_acc(y_pred, y_test):
    y_pred_tag = torch.round(torch.sigmoid(y_pred))
    correct_results_sum = (y_pred_tag == y_test).sum().float()
    acc = correct_results_sum/y_test.shape[0]
    acc = torch.round(acc * 100)
    return acc    


def get_val_set_acc(model, val_set): 
    val_loader = DataLoader(dataset=val_set, batch_size=len(val_set))
    model = model.eval()
    for iter, (bg, label_v) in enumerate(val_loader):
             
         prediction = model(bg.float())
         v_set_acc  = binary_acc(prediction, label_v.unsqueeze(1).float())
    return v_set_acc    
    
    

def objective(trial):    
    num_epochs       = trial.suggest_int('num_epochs', 50, 200) # TODO:Change to: (10k, 20k) :) 
    layer_1_dim      = trial.suggest_int('n_units_l_1', 10, 1024)
    layer_2_dim      = trial.suggest_int('n_units_l_2', 10, 1024)
    dropout_rate     = trial.suggest_float('dropout_l', 0.2, 0.5)
    patience         = trial.suggest_int('patience', 10, 200)    # TODO: The patience needs to be tuned 
    lr = trial.suggest_float("lr", 1e-5, 5e-1, log=True)
    criterion = nn.BCEWithLogitsLoss()
    
    train_set, val_set, test_set = get_data() # use_out_norm TO BE SET!    
    batch_size        = trial.suggest_int('batch_size', 16, len(train_set))
    
    model = Reg(layer_1_dim, layer_2_dim, dropout_rate) 
    data_loader      = DataLoader(train_set, batch_size=batch_size, shuffle=True) 

    if use_gpu: model = model.cuda()
    
    early_stopping = EarlyStopping(patience=patience, verbose=True)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    for epoch in range(num_epochs):
        epoch_loss = 0
        model = model.train()
        for iter, (bg, label) in enumerate(data_loader):
            if use_gpu: 
                bg    = bg.cuda()
                label = label.cuda()
                
            prediction = model(bg.float())
    
            loss = criterion(prediction, label.unsqueeze(1).float())
            
            optimizer.zero_grad()
            loss.backward()
            
            optimizer.step()
            epoch_loss += loss.detach().item()
    
        epoch_loss /= (iter + 1)
        
        val_set_acc = get_val_set_acc(model, val_set)
        val_loss_best = early_stopping(trial, epoch, val_set_acc, model)
        trial.report(val_loss_best, epoch)  
        
        train_acc = get_val_set_acc(model, train_set)
        print('Epoch: {}, loss: {:.4f}, Acc: {:.4f}, Val_acc: {:.4f}'.format(epoch, epoch_loss/len(data_loader), train_acc, val_set_acc))
        
        if early_stopping.early_stop:
            print('EARLY STOPPING MODEL :) ')
            return val_loss_best
         
        # Handle pruning based on the intermediate value.
        if trial.should_prune():
            raise optuna.exceptions.TrialPruned()
        
    return val_loss_best

if __name__ == '__main__': 
    
    # use_out_norm # TODO: TO BE SET! 
    use_gpu = False
    study_name = 'example-study-st'
    study = optuna.create_study(direction="maximize", study_name=study_name, storage='sqlite:///example_st.db', load_if_exists=True) 

    # Data frame that has the history: 
    df = study.trials_dataframe(attrs=('number', 'value', 'params', 'state'))
    
    study.optimize(objective, n_trials=20000, timeout=86000) # TODO
    
    pruned_trials = [t for t in study.trials if t.state == optuna.trial.TrialState.PRUNED]
    complete_trials = [t for t in study.trials if t.state == optuna.trial.TrialState.COMPLETE]
    
    trial = study.best_trial
    print("  Value: ", trial.value)
    
    
    # Calculate performance of test set: 
    _, _, test_set = get_data()
    
    model_testing = torch.load('./saved_models_st/{}/model_checkpoint.pt'.format(trial.number))
    model_testing.eval()
    
    test_acc = get_val_set_acc(model_testing, test_set)
    print('Test Acc is: ', test_acc)

    
    # from plotly.offline import plot
    # A = optuna.visualization.plot_intermediate_values(study)
    # plot(A)
        
            

import os
# import sys
import random
import optuna
import pickle
import pandas as pd

# import matplotlib.pyplot as plt
import numpy as np
import torch 
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from sklearn import metrics


from rdkit import Chem
from rdkit.Chem import AllChem, DataStructs


def get_fp_score(smiles_back): 
    
    mol    = Chem.MolFromSmiles(smiles_back)
    if mol == None: 
        raise Exception('Invalid molecule encountered when calculating fingerprint')
    fp_mol = AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=1024)
    
    A = np.zeros((0,), dtype=np.int8)
    DataStructs.ConvertToNumpyArray(fp_mol, A)
    
    return A


def create_classification_datat(file_name): 
    train_ratio = 0.8
    with open('./DATA/{}'.format(file_name), 'rb') as handle:
         collected_dict = pickle.load(handle)    
    
    smiles_           = list(collected_dict.keys()) # All the smiles for which there are calculations! 
    bin_class         = []
    
    count_bad = 0
    count_good = 0
    for key in smiles_: 
        # singlet_trip.append(collected_dict[key][0])
        # oscillator_stngth.append(collected_dict[key][1])
        if collected_dict[key][1] < 0.0 or collected_dict[key][0] >= 0.6: 
            bin_class.append(0) # BAD! 
            count_bad += 1
        else: 
            bin_class.append(1) # GOOD! 
            count_good += 1
    
    print('{} Bad examples & {} Good examples'.format(count_bad, count_good))
    print('Acquiring fingerprints! ...')
    graph_ls       = [get_fp_score(smi) for smi in smiles_]
    print('Fingerprint acquisition complete! ')
    collected_data = [(graph_ls[i], bin_class[i]) for i in range(len(smiles_))]
    
    
    idx = [i for i in range(len(collected_data))]
    
    random.seed(1)
    train_indices = random.sample(idx, int(train_ratio*len(idx)))
    
    
    idx = list(set(idx) - set(train_indices))
    random.seed(1)
    val_indices = random.sample(idx, int(0.4*len(idx)))
    
    test_indices = list(set(idx) - set(val_indices))
    
    train_set = [collected_data[i] for i in train_indices]
    val_set   = [collected_data[i] for i in val_indices]
    test_set  = [collected_data[i] for i in test_indices]
    
    with open('./DATA/exp_6_split/train_classification.pkl', 'wb') as f:
        pickle.dump(train_set, f)
        
    with open('./DATA/exp_6_split/val_classification.pkl', 'wb') as f:
        pickle.dump(val_set, f)    
        
    with open('./DATA/exp_6_split/test_classification.pkl', 'wb') as f:
        pickle.dump(test_set, f)    
        
    return train_set, val_set, test_set
    
train_set, val_set, test_set = create_classification_datat('exp_6_symm.pickle')

    
# Read in data test: 
def get_classification_data(): 
    with open('./data/test_classification.pkl', 'rb') as f:
        A = pickle.load(f)        

    with open('./data/val_classification.pkl', 'rb') as f:
        B = pickle.load(f)        
        
    with open('./data/train_classification.pkl', 'rb') as f:
        C = pickle.load(f)        
    
           # Train, Val & Test
    return C, B, A
    

def save_pickle(train_set, val_set, test_set, key_): 
    with open('./data/train_norm_{}_pred.pkl'.format(key_), 'wb') as f:
        pickle.dump(train_set, f)
        
    with open('./data/val_norm_{}_pred.pkl'.format(key_), 'wb') as f:
        pickle.dump(val_set, f)    
        
    with open('./data/test_norm_{}_pred.pkl'.format(key_), 'wb') as f:
        pickle.dump(test_set, f)    
    
    return 
    

def norm_data(data): 
    pre_norm_arr_inp = []
    # pre_norm_out     = []
    for item in data: 
        pre_norm_arr_inp.append(item[0][0:33])
        # pre_norm_out.append(item[1])
    
    # print('OUT: ', pre_norm_out)
    # print('Len: ', len(pre_norm_out))
    # pre_norm_out = np.array(pre_norm_out)
    # max_out, min_out = np.max(pre_norm_out), np.min(pre_norm_out)
    # print('Max: {}; Min: {}'.format(max_out, min_out))
    
    # pre_norm_out = (pre_norm_out - min_out) / (max_out - min_out)
    # raise Exception('TEST')
    
    pre_norm_arr_inp = np.array(pre_norm_arr_inp)
    
    max_vals = np.max(pre_norm_arr_inp, axis=0)
    min_vals = np.min(pre_norm_arr_inp, axis=0)
    
    
    
    
    for i in range(pre_norm_arr_inp.shape[1]): 
        
        arr_ = pre_norm_arr_inp[:, i]
        arr_ = (arr_ - min_vals[i]) / (max_vals[i] - min_vals[i])
        
        pre_norm_arr_inp[:, i] = arr_
    
    
    for i in range(len(pre_norm_arr_inp)): 
        
        data[i][0][0:33] = pre_norm_arr_inp[i]
        # A = data[i][0]
        # A[0:33] = pre_norm_arr_inp[i]
        # out_    = pre_norm_out[i]
       
        # data[i] = (A, out_)
        # print(data[i])
        # raise Exception('X')

        
    return data


def get_pred_data(key_): 
    with open('./data/train_norm_{}_pred.pkl'.format(key_), 'rb') as f:
        A = pickle.load(f)        

    with open('./data/val_norm_{}_pred.pkl'.format(key_), 'rb') as f:
        B = pickle.load(f)        
        
    with open('./data/test_norm_{}_pred.pkl'.format(key_), 'rb') as f:
        C = pickle.load(f)        
    
           # Train, Val & Test
    return A, B, C


    
if __name__ == '__main__': 
    key_        = 'oscillator' # or oscillator, singlet
    train_ratio = 0.8
    with open('./data/gdb.pickle', 'rb') as handle:
         collected_dict = pickle.load(handle)    
         
    with open('./data/3d_fing.pickle', 'rb') as handle:
         fing_data = pickle.load(handle)    
    raise Exception('CHECK')
    
    smiles_           = list(collected_dict.keys()) # All the smiles for which there are calculations! 
    # bin_class         = []
    singlet_trip      = []
    oscillator_stngth = []
    
    
    if key_ == 'singlet': 
        collected_data = []
        for key in smiles_: 
    
            if collected_dict[key][1] < 0.0 or collected_dict[key][0] >= 0.6: 
                continue # No need to bother with predictions1 
            else: 
                
                if key in fing_data: 
                    sing_val = collected_dict[key][0]
                    fp_data  = fing_data[key]
                    fp_data = np.concatenate((fp_data[0], fp_data[1]))
                    
                    collected_data.append((fp_data, sing_val))
                else: 
                    continue
                
                
    elif key_ == 'oscillator': 
        collected_data = []
        for key in smiles_: 
    
            if collected_dict[key][1] < 0.0 or collected_dict[key][0] >= 0.6: 
                continue # No need to bother with predictions1 
            else: 
                
                if key in fing_data: 
                    osc_val = collected_dict[key][1]
                    fp_data  = fing_data[key]
                    fp_data = np.concatenate((fp_data[0], fp_data[1]))
                    
                    collected_data.append((fp_data, osc_val))     
                else: 
                    continue
                
    
    
    idx = [i for i in range(len(collected_data))]
    
    random.seed(1)
    train_indices = random.sample(idx, int(train_ratio*len(idx)))
    
    
    idx = list(set(idx) - set(train_indices))
    random.seed(1)
    val_indices = random.sample(idx, int(0.4*len(idx)))
    
    test_indices = list(set(idx) - set(val_indices))
    
    train_set = [collected_data[i] for i in train_indices]
    val_set   = [collected_data[i] for i in val_indices]

    test_set  = [collected_data[i] for i in test_indices]
    
    
    # Obtain the normalized data (only the inputs are normalized)
    train_set = norm_data(train_set.copy())
    val_set = norm_data(val_set.copy())
    test_set = norm_data(test_set.copy())
    
    
    save_pickle(train_set, val_set, test_set, key_)





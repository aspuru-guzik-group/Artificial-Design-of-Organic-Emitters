#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 21 09:37:18 2021

@author: akshat
"""

import os
# import sys
import random
import optuna
import pickle
import pandas as pd

# import matplotlib.pyplot as plt
import numpy as np
import torch 
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from sklearn import metrics


from rdkit import Chem
from rdkit.Chem import AllChem, DataStructs
# from get_class_data import get_classification_data


# def get_classification_data(): 
#     with open('./data/test_classification.pkl', 'rb') as f:
#         A = pickle.load(f)        

#     with open('./data/val_classification.pkl', 'rb') as f:
#         B = pickle.load(f)        
        
#     with open('./data/train_classification.pkl', 'rb') as f:
#         C = pickle.load(f)        
    
#            # Train, Val & Test
#     return C, B, A
    

def get_classification_data(): 
    with open('./DATA/exp_2_split/train_classification.pkl', 'rb') as f:
        A = pickle.load(f)        

    with open('./DATA/exp_2_split/val_classification.pkl', 'rb') as f:
        B = pickle.load(f)        
        
    with open('./DATA/exp_2_split/test_classification.pkl', 'rb') as f:
        C = pickle.load(f)        
    
           # Train, Val & Test
    return A, B, C


class EarlyStopping:
    """Early stops the training if validation loss doesn't improve after a given patience."""
    def __init__(self, patience=7, verbose=False, delta=0, path='checkpoint.pt'):
        """
        Args:
            patience (int): How long to wait after last time validation loss improved.
                            Default: 7
            verbose (bool): If True, prints a message for each validation loss improvement. 
                            Default: False
            delta (float): Minimum change in the monitored quantity to qualify as an improvement.
                            Default: 0
            path (str): Path for the checkpoint to be saved to.
                            Default: 'checkpoint.pt'
        """
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta
        self.path = path

    def __call__(self, epoch, val_loss, model):

        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model, epoch)
            # trial.report(val_loss, epoch) #### TESTING
        elif score > self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model, epoch)
            self.counter = 0
        
        return self.val_loss_min

    def save_checkpoint(self, val_loss, model, epoch):
        '''Saves model when validation loss decrease.'''
        if os.path.isdir('./saved_models_class/') == False: 
            os.system('mkdir ./saved_models_class/') # create directory that saves the model 
        self.path = './saved_models_class/model_checkpoint.pt'
        torch.save(model, self.path)
        self.val_loss_min = val_loss
        

#our class must extend nn.Module
class binaryClassification(nn.Module):
    def __init__(self):
        super(binaryClassification, self).__init__()
        # Number of input features is 12.
        self.layer_1 = nn.Linear(1024, 64) 
        self.layer_2 = nn.Linear(64, 64)
        self.layer_out = nn.Linear(64, 1) 
        
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(p=0.1)
        self.batchnorm1 = nn.BatchNorm1d(64)
        self.batchnorm2 = nn.BatchNorm1d(64)
        
    def forward(self, inputs):
        x = self.relu(self.layer_1(inputs))
        x = self.batchnorm1(x)
        x = self.relu(self.layer_2(x))
        x = self.batchnorm2(x)
        x = self.dropout(x)
        x = self.layer_out(x)
        
        return x
    
def binary_acc(y_pred, y_test):
    y_pred_tag = torch.round(torch.sigmoid(y_pred))

    correct_results_sum = (y_pred_tag == y_test).sum().float()
    acc = correct_results_sum/y_test.shape[0]
    acc = torch.round(acc * 100)
    
    return acc    

def print_t_set_acc(): 
    test_loader = DataLoader(dataset=test, batch_size=len(test))
    
    # device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # device = torch.device("cpu")
    
    # y_pred_list = []
    model = torch.load('./saved_models_class/model_checkpoint.pt')
    model = model.eval()
    for iter, (bg, label_t) in enumerate(test_loader):
             
         prediction = model(bg.float())
    
         t_set_acc  = binary_acc(prediction, label_t.unsqueeze(1).float())
    
    # y_pred_list = [a.squeeze().tolist() for a in y_pred_list]
    print('Test Set Acc: ', t_set_acc)

def get_val_set_acc(model): 
    val_loader = DataLoader(dataset=val, batch_size=len(val))
    
    # device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # device = torch.device("cpu")
    
    # y_pred_list = []
    model = model.eval()
    for iter, (bg, label_v) in enumerate(val_loader):
             
         prediction = model(bg.float())
    
         v_set_acc  = binary_acc(prediction, label_v.unsqueeze(1).float())
    
    return v_set_acc
    # print('Test Set Acc: ', t_set_acc)
    
    
    
train, val, test = get_classification_data()    
    
# train = train[0:1000] # TODO: For testing 
batch_size = len(train) # TODO    
lr         = 0.001 # TODO
num_epochs = 100
patience   = 200 

#Initialize the model        
model = binaryClassification()
#Define loss criterion
criterion = nn.BCEWithLogitsLoss()

#Define the optimizer
optimizer = torch.optim.Adam(model.parameters(), lr=lr)
early_stopping = EarlyStopping(patience=patience, verbose=True)



data_loader      = DataLoader(train, batch_size=batch_size, shuffle=True) 

optimizer = torch.optim.Adam(model.parameters(), lr=lr)

for epoch in range(num_epochs):
    epoch_loss, epoch_acc = 0, 0
    model = model.train()
    for iter, (bg, label) in enumerate(data_loader):
            
        prediction = model(bg.float())

        # loss = ( (prediction-label.reshape((label.shape[0], 1)))**2 ).mean()
        loss = criterion(prediction, label.unsqueeze(1).float())
        acc  = binary_acc(prediction, label.unsqueeze(1).float())
        # raise Exception('TESTING! ')

        
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        epoch_loss += loss.detach().item()
        epoch_acc  += acc.item()

    # epoch_loss /= (iter + 1)
    
    val_set_acc = get_val_set_acc(model)
    val_loss_best = early_stopping(epoch, val_set_acc, model)
    # trial.report(val_loss_best, epoch)  ### TESTING 
    # print(f'Epoch {e+0:03}: | Loss: {epoch_loss/len(train_loader):.5f} | Acc: {epoch_acc/len(train_loader):.3f}')
    print('Epoch: {}, loss: {:.4f}, Acc: {:.4f}, Val_acc: {:.4f}'.format(epoch, epoch_loss/len(data_loader), epoch_acc/len(data_loader), val_set_acc))

    if early_stopping.early_stop:
        print('EARLY STOPPING MODEL :) ')
        break 

# Final testing of the model: 
print_t_set_acc()



# PRINT SOME DETAILS!! :        

    

test_loader = DataLoader(dataset=test, batch_size=len(test))

# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# device = torch.device("cpu")

# y_pred_list = []
model = torch.load('./saved_models_class/model_checkpoint.pt')
model = model.eval()
for iter, (bg, label_t) in enumerate(test_loader):
         
     prediction = model(bg.float())

     # t_set_acc  = binary_acc(prediction, label_t.unsqueeze(1).float())



y_pred_tag = torch.round(torch.sigmoid(prediction))

num_1, num_0 = 0, 0


for i in range(len(y_pred_tag)): 
    
    pred_ = y_pred_tag[i]
    act_  = label_t[i]
    
    if act_ == 1 and pred_ == 0: 
        num_1 += 1 # False negatives! 
    if act_ == 0 and pred_ == 1: 
        num_0 += 1 # False positives! 
    

print('Number of --  False positives: {}; False negatives: {}'.format(num_0, num_1))
    